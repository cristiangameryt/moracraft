<?php 
/*
 *	Made by Samerton
 *  http://worldscapemc.co.uk
 *
 *  License: MIT
 *  Copyright (c) 2016 Samerton
 */
// Language file for "Donate" addon
$donate_language = array(
	'donate' => 'Donere',
	'donate_icon' => '', // Ikonet for å vise før "Donate" i navbar
	'latest_donors' => 'Siste donators',
	'agree_with_terms' => 'Ved å donere, samtykker du i vilkårene',
	'link' => '(Link)',
	'agree' => 'Enig &raquo;',
	'cancel' => 'Kansellere',
	'select' => 'Velg'
);
