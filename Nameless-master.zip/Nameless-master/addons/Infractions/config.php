<?php
$inf_db = array(
    'address' => '127.0.0.1',
    'name' => '',
    'username' => '',
    'password' => '',
	'prefix' => ''
);